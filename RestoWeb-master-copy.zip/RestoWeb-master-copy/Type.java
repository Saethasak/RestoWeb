public enum Type{
    DESSERT, VEGAN, APPETIZERS, DINER;
}